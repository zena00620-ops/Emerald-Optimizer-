package dev.emerald.optimizer;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;

public final class EmeraldScreen extends Screen {
    private String status = "Ready";

    public EmeraldScreen() { super(new LiteralText("EMERALD OPTIMIZER")); }

    @Override
    protected void init() {
        int x = this.width / 2 - 105;
        int y = this.height / 2 - 8;
        this.addButton(new ButtonWidget(x, y, 210, 20,
                new LiteralText("APPLY ULTRA LOW"), button -> {
                    EmeraldOptimizer.applyUltraLow(MinecraftClient.getInstance());
                    status = "ULTRA LOW profile applied";
                }));
        this.addButton(new ButtonWidget(x, y + 26, 210, 20,
                new LiteralText("DONE"), button -> this.client.openScreen(null)));
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);
        fill(matrices, 0, 0, this.width, this.height, 0xE9101713);
        fill(matrices, this.width / 2 - 122, this.height / 2 - 88,
                this.width / 2 + 122, this.height / 2 + 83, 0xFF17251D);
        fill(matrices, this.width / 2 - 122, this.height / 2 - 88,
                this.width / 2 + 122, this.height / 2 - 85, 0xFF36D17C);
        drawCenteredText(matrices, this.textRenderer, "EMERALD OPTIMIZER",
                this.width / 2, this.height / 2 - 69, 0xFF7CFFB0);
        drawCenteredText(matrices, this.textRenderer, "Minecraft 1.16.5 | Fabric",
                this.width / 2, this.height / 2 - 49, 0xFFD0DDD4);
        drawCenteredText(matrices, this.textRenderer, "Profile: ULTRA LOW",
                this.width / 2, this.height / 2 - 28, 0xFFFFFFFF);
        drawCenteredText(matrices, this.textRenderer, status,
                this.width / 2, this.height / 2 + 61, 0xFF9BE9B8);
        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
