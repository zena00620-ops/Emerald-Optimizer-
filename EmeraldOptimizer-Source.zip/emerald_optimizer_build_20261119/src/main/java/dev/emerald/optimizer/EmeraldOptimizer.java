package dev.emerald.optimizer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleStatus;
import org.lwjgl.glfw.GLFW;

public final class EmeraldOptimizer implements ClientModInitializer {
    public static final String MOD_ID = "emerald_optimizer";
    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.emerald_optimizer.open", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O, "category.emerald_optimizer"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) client.openScreen(new EmeraldScreen());
            }
        });
    }

    public static void applyUltraLow(MinecraftClient client) {
        if (client == null || client.options == null) return;
        // Vanilla options only: no mixins into Sodium or Minecraft's renderer.
        client.options.viewDistance = 4;
        client.options.clouds = false;
        client.options.particles = ParticleStatus.MINIMAL;
        client.options.mipmapLevels = 0;
        client.options.fancyGraphics = false;
        client.options.ao = false;
        client.options.write();
    }
}
