# Emerald Optimizer 0.1.0

Client-side Fabric prototype for Minecraft 1.16.5.

## Included
- Emerald-themed custom menu, opened with **O**.
- One-click **ULTRA LOW** profile.
- Applies vanilla options: render distance 4, clouds off, minimal particles, mipmaps 0, fast graphics and ambient occlusion off.
- Does not patch Sodium internals and does not require Sodium. This is a conservative compatibility approach, not a claim of verified compatibility with every Sodium build.

## Build
Install JDK 8 and Gradle 7.3.3, then run `gradle build` in this folder.
The output JAR is placed in `build/libs/`.

The project uses Fabric Loom 0.10-SNAPSHOT, Yarn 1.16.5+build.10, Fabric Loader 0.14.25 and Fabric API 0.42.0+1.16.5. Gradle downloads dependencies, so the first build needs internet access.

## Install
Install Fabric Loader and Fabric API for Minecraft 1.16.5. Copy the generated `emerald-optimizer-0.1.0.jar` from `build/libs/` into `.minecraft/mods`. Sodium is optional.

## Prototype limitations
This version adjusts vanilla visual options only. It does not yet optimize chunk generation, entity ticking, memory management, or disk I/O. Benchmark before/after on the same world. Back up options and test in a copy of a world.
